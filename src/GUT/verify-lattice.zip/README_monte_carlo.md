# SU(4) Deficit Lattice Monte Carlo — Production Suite

## Overview

Monte Carlo simulation of SU(4) lattice gauge theory with the deficit entanglement
involution, testing the dynamical Pati-Salam breaking mechanism:

    SU(4) → SU(3) × U(1)_{B-L}

via antiferromagnetic Ising ordering of the original/deficit checkerboard.

## Files

| File | Description |
|------|-------------|
| `su4_deficit_mc_production.cpp` | Production simulation (OpenMP parallelized) |
| `su4_deficit_mc.cpp` | Original single-threaded prototype |
| `run_production.sh` | Orchestration script for full run suite |
| `plot_results.py` | Plotting script (reads CSV output) |

## Quick Start

```bash
# Compile (requires g++ with C++17 and OpenMP)
g++ -O3 -std=c++17 -fopenmp -march=native -o su4mc_prod su4_deficit_mc_production.cpp -lm

# Quick validation run (~5 minutes)
export OMP_NUM_THREADS=60
./su4mc_prod --Ls 4 --Lt 6 --n_therm 50 --n_meas 20 --interval 3 --scan

# Production beta scan on 8^3 × 16 (~2-4 hours)
./su4mc_prod --Ls 8 --Lt 16 --n_therm 300 --n_meas 100 --interval 5 --scan

# High statistics at single beta (~1-2 hours)
./su4mc_prod --beta 4.0 --Ls 8 --Lt 16 --n_therm 500 --n_meas 300 --interval 5

# Larger lattice (~12-24 hours)
./su4mc_prod --Ls 12 --Lt 24 --n_therm 400 --n_meas 80 --interval 8 --scan

# Full finite-size scaling (~24-48 hours)
./su4mc_prod --sizes --n_therm 400 --n_meas 100 --interval 6

# Or run everything in sequence:
bash run_production.sh
```

## Plotting

```bash
# Requires matplotlib and numpy
pip install matplotlib numpy

# Plot results from a single run
python3 plot_results.py su4_results.csv

# Plot finite-size scaling results
python3 plot_results.py results_*/run5_fss.csv --fss

# Combine multiple runs
python3 plot_results.py results_*/*.csv --combined
```

## System Requirements

For the recommended production runs:

| Run | Lattice | Threads | RAM | Time |
|-----|---------|---------|-----|------|
| Validation | 4³ × 6 | any | < 1 GB | 5 min |
| Beta scan | 8³ × 16 | 60 | < 1 GB | 2-4 hr |
| High stats | 8³ × 16 | 60 | < 1 GB | 1-2 hr |
| Large lattice | 12³ × 24 | 60 | ~2 GB | 12-24 hr |
| Finite-size scaling | 6-12³ × 12-24 | 60 | ~2 GB | 24-48 hr |

Memory is not the bottleneck. All lattice data fits in < 5 GB even for 16³ × 32.

## What It Measures

For each (beta, lattice size) and each of three fixed Ising configurations
(ordered/disordered/uniform):

1. **Average plaquette** — proportional to minus the Wilson action density.
   Higher plaquette = lower action = energetically preferred.

2. **Colour Polyakov loop** |L_col| — trace of the temporal Wilson loop
   projected onto the {v1, v2, v3} subspace (magic basis). Should grow
   in the ordered phase.

3. **Leptoquark Polyakov loop** |L_lep| — off-diagonal blocks connecting
   {v1,v2,v3} ↔ {v4}. Should be suppressed in the ordered phase.

4. **Eigenvalue spread** — standard deviation of the first three eigenphases
   of the temporal N·N_bar product. Should approach zero in the ordered phase
   (= perfect 3+1 degeneracy = SU(3) × U(1)).

## Method: Quenched Ising Comparison

The Ising labels σ = ±1 cannot be efficiently sampled by local Metropolis
(acceptance rate ~ exp(-24J) ≈ 0). Instead, we fix the Ising configuration
in three competing phases and equilibrate the gauge sector in each:

- **Ordered**: σ_f = (-1)^{x+y+z+t} (checkerboard)
- **Disordered**: σ_f random
- **Uniform**: σ_f = +1 (all original, no deficit tetrahedra)

The phase with the highest average plaquette (lowest action) wins. This is the
standard approach for comparing metastable phases in lattice gauge theory.

The gauge sector (connections W ∈ SU(2)² and Weyl parameters c ∈ [0, π/4]³)
is updated by Metropolis with adaptive step sizes, parallelized over even/odd
sites (checkerboard decomposition in the gauge sector, unrelated to the Ising
checkerboard).

## Expected Results

Based on preliminary runs (4³ × 6, 10-20 measurements):

| β | plaq_ord | plaq_dis | col/lep ratio | eig. spread |
|---|----------|----------|---------------|-------------|
| 0.5 | 0.29 | 0.29 | 0.65 | 0.45 |
| 1.0 | 1.10 | 0.64 | 0.64 | 0.36 |
| 2.0 | 2.85 | 1.43 | 1.31 | 0.22 |
| 4.0 | 3.46 | 2.01 | 2.28 | 0.15 |
| 6.0 | 3.65 | 2.19 | 3.00 | 0.12 |

All trends should strengthen on larger lattices.

## Output Format

CSV with columns:
```
beta, Ls, Lt, vol, phase, plaq, plaq_err, Lcol, Lcol_err, Llep, Llep_err, spread, spread_err, col_lep_ratio
```

## Citation

If you use this code, please cite:

A. K. Kelleher and G. Heileman, "Dynamical Pati-Salam Breaking:
Antiferromagnetic Ising Order from the Dimensionality Mismatch
dim m⁻ = 3 < 6 = dim m," (2026).

## License

MIT
