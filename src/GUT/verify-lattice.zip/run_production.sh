#!/bin/bash
# =============================================================================
# run_production.sh
#
# Production runs for the SU(4) deficit lattice Monte Carlo.
# Designed for a 64-core / 128GB machine.
#
# Estimated runtimes (very rough):
#   Beta scan on 8^3 x 16:    ~2-4 hours
#   Beta scan on 12^3 x 24:   ~12-24 hours
#   Finite-size scaling:       ~24-48 hours
#   Full production:           ~3-5 days
# =============================================================================

set -e

# Compile
echo "=== Compiling ==="
g++ -O3 -std=c++17 -fopenmp -march=native -o su4mc_prod su4_deficit_mc_production.cpp -lm
echo "Done. Using $(./su4mc_prod --help 2>&1 | head -1 || true)"
echo ""

# Create output directory
OUTDIR="results_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUTDIR"
echo "Output directory: $OUTDIR"
echo ""

# Set thread count (leave a few cores for the OS)
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-60}
echo "Using $OMP_NUM_THREADS threads"
echo ""

# =============================================================================
# Run 1: Quick validation (should match the preliminary results)
# ~10 minutes
# =============================================================================
echo "=== Run 1: Quick validation (4^3 x 6) ==="
./su4mc_prod --Ls 4 --Lt 6 --n_therm 100 --n_meas 30 --interval 3 \
    --scan --outdir "$OUTDIR" 2>&1 | tee "$OUTDIR/run1_validation.log"
mv "$OUTDIR/su4_results.csv" "$OUTDIR/run1_validation.csv"
echo ""

# =============================================================================
# Run 2: Beta scan at production size
# ~2-4 hours
# =============================================================================
echo "=== Run 2: Beta scan (8^3 x 16) ==="
./su4mc_prod --Ls 8 --Lt 16 --n_therm 300 --n_meas 100 --interval 5 \
    --scan --outdir "$OUTDIR" 2>&1 | tee "$OUTDIR/run2_8x16.log"
mv "$OUTDIR/su4_results.csv" "$OUTDIR/run2_8x16.csv"
echo ""

# =============================================================================
# Run 3: Higher statistics at key beta values
# ~6-12 hours
# =============================================================================
echo "=== Run 3: High statistics at key betas (8^3 x 16) ==="
for beta in 2.0 3.0 4.0 6.0; do
    echo "--- beta = $beta ---"
    ./su4mc_prod --beta $beta --Ls 8 --Lt 16 --n_therm 500 --n_meas 300 --interval 5 \
        --outdir "$OUTDIR" 2>&1 | tee -a "$OUTDIR/run3_high_stats.log"
    mv "$OUTDIR/su4_results.csv" "$OUTDIR/run3_beta${beta}.csv"
done
echo ""

# =============================================================================
# Run 4: Larger lattice
# ~12-24 hours
# =============================================================================
echo "=== Run 4: Larger lattice (12^3 x 24) ==="
./su4mc_prod --Ls 12 --Lt 24 --n_therm 400 --n_meas 80 --interval 8 \
    --scan --outdir "$OUTDIR" 2>&1 | tee "$OUTDIR/run4_12x24.log"
mv "$OUTDIR/su4_results.csv" "$OUTDIR/run4_12x24.csv"
echo ""

# =============================================================================
# Run 5: Finite-size scaling (multiple sizes at same betas)
# ~24-48 hours
# =============================================================================
echo "=== Run 5: Finite-size scaling ==="
./su4mc_prod --sizes --n_therm 400 --n_meas 100 --interval 6 \
    --outdir "$OUTDIR" 2>&1 | tee "$OUTDIR/run5_fss.log"
mv "$OUTDIR/su4_results.csv" "$OUTDIR/run5_fss.csv"
echo ""

echo "=== All runs complete ==="
echo "Results in: $OUTDIR/"
ls -la "$OUTDIR"/*.csv
