// =============================================================================
// su4_deficit_mc_production.cpp
//
// Production Monte Carlo for SU(4) deficit lattice gauge theory.
// Parallelized with OpenMP. Designed for 64-core / 128GB systems.
//
// Features:
//   - OpenMP checkerboard parallelization (even/odd site decomposition)
//   - Multiple lattice sizes for finite-size scaling
//   - Beta scan with automatic phase comparison
//   - Jackknife error estimation
//   - Over-relaxation microcanonical updates for faster decorrelation
//   - Data output to CSV for plotting
//
// Compile:
//   g++ -O3 -std=c++17 -fopenmp -march=native -o su4mc_prod su4_deficit_mc_production.cpp -lm
//
// Run examples:
//   ./su4mc_prod                          # default: beta scan on 8^3 x 16
//   ./su4mc_prod --Ls 12 --Lt 24         # specific size
//   ./su4mc_prod --beta 4.0 --Ls 16 --Lt 32 --n_meas 500  # single beta, high stats
//   ./su4mc_prod --scan --sizes           # full scan over multiple sizes
//
// Authors: Andrew K. Kelleher and Grant Heileman, Twin Vector Labs
// =============================================================================

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <complex>
#include <random>
#include <array>
#include <vector>
#include <algorithm>
#include <numeric>
#include <chrono>
#include <string>
#include <fstream>
#include <omp.h>

using cd = std::complex<double>;
constexpr double PI = 3.14159265358979323846;
constexpr int NDIM = 4;

// ===================== 4x4 Complex Matrix =====================

struct Mat4 {
    cd m[4][4];

    Mat4() { memset(m, 0, sizeof(m)); }

    static Mat4 identity() {
        Mat4 r;
        for (int i = 0; i < 4; i++) r.m[i][i] = 1.0;
        return r;
    }

    Mat4 operator*(const Mat4& b) const {
        Mat4 r;
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++) {
                cd s = 0;
                for (int k = 0; k < 4; k++) s += m[i][k] * b.m[k][j];
                r.m[i][j] = s;
            }
        return r;
    }

    Mat4 operator+(const Mat4& b) const {
        Mat4 r;
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
                r.m[i][j] = m[i][j] + b.m[i][j];
        return r;
    }

    Mat4 adjoint() const {
        Mat4 r;
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
                r.m[i][j] = std::conj(m[j][i]);
        return r;
    }

    cd trace() const { return m[0][0] + m[1][1] + m[2][2] + m[3][3]; }
};

// ===================== SU(2) as Quaternion =====================

struct SU2 {
    double a[4]; // (a0, a1, a2, a3), |a|^2 = 1

    static SU2 identity() { return {1, 0, 0, 0}; }

    SU2 operator*(const SU2& b) const {
        return {
            a[0]*b.a[0] - a[1]*b.a[1] - a[2]*b.a[2] - a[3]*b.a[3],
            a[0]*b.a[1] + a[1]*b.a[0] + a[2]*b.a[3] - a[3]*b.a[2],
            a[0]*b.a[2] - a[1]*b.a[3] + a[2]*b.a[0] + a[3]*b.a[1],
            a[0]*b.a[3] + a[1]*b.a[2] - a[2]*b.a[1] + a[3]*b.a[0]
        };
    }

    SU2 dagger() const { return {a[0], -a[1], -a[2], -a[3]}; }

    void normalize() {
        double n = sqrt(a[0]*a[0] + a[1]*a[1] + a[2]*a[2] + a[3]*a[3]);
        if (n > 1e-15) for (int i = 0; i < 4; i++) a[i] /= n;
    }

    void to_matrix(cd out[2][2]) const {
        out[0][0] = cd(a[0], a[3]);  out[0][1] = cd(a[2], a[1]);
        out[1][0] = cd(-a[2], a[1]); out[1][1] = cd(a[0], -a[3]);
    }
};

// ===================== Tensor Product =====================

Mat4 embed_su2xu2(const SU2& wL, const SU2& wR) {
    cd L[2][2], R[2][2];
    wL.to_matrix(L);
    wR.to_matrix(R);
    Mat4 result;
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            for (int k = 0; k < 2; k++)
                for (int l = 0; l < 2; l++)
                    result.m[2*i+j][2*k+l] = L[i][k] * R[j][l];
    return result;
}

// ===================== Magic Basis =====================

static const double ISQRT2 = 1.0 / sqrt(2.0);
static const int sign_vectors[4][3] = {
    {+1,-1,+1}, {-1,+1,+1}, {+1,+1,-1}, {-1,-1,-1}
};

Mat4 magic_basis_M() {
    Mat4 M;
    M.m[0][0] = ISQRT2; M.m[3][0] = ISQRT2;
    M.m[0][1] = ISQRT2; M.m[3][1] = -ISQRT2;
    M.m[1][2] = ISQRT2; M.m[2][2] = ISQRT2;
    M.m[1][3] = ISQRT2; M.m[2][3] = -ISQRT2;
    return M;
}

// Global cached magic basis (computed once)
static const Mat4 G_M = magic_basis_M();
static const Mat4 G_Mdag = magic_basis_M().adjoint();

Mat4 nonlocal_core(const double c[3], int sigma) {
    double cc[3];
    for (int i = 0; i < 3; i++)
        cc[i] = (sigma == 1) ? c[i] : (PI/4.0 - c[i]);
    Mat4 D;
    for (int k = 0; k < 4; k++) {
        double lambda = 0;
        for (int i = 0; i < 3; i++) lambda += sign_vectors[k][i] * cc[i];
        D.m[k][k] = std::exp(cd(0, -lambda));
    }
    return G_M * D * G_Mdag;
}

// ===================== Lattice =====================

struct Lattice {
    int Ls, Lt, vol;
    double beta;

    std::vector<std::array<double,3>> weyl;
    std::vector<int> ising;
    std::vector<std::array<SU2,NDIM>> connL, connR;

    // Per-thread RNGs
    std::vector<std::mt19937_64> rngs;
    std::vector<std::uniform_real_distribution<double>> uniforms;

    // Precomputed neighbour tables
    std::vector<std::array<int,NDIM>> fwd, bwd;
    std::vector<int> parities; // (-1)^{x+y+z+t}

    // Even/odd site lists for checkerboard parallelization
    std::vector<int> even_sites, odd_sites;

    Lattice(int Ls_, int Lt_, double beta_, unsigned base_seed = 12345)
        : Ls(Ls_), Lt(Lt_), beta(beta_)
    {
        vol = Ls * Ls * Ls * Lt;
        int nthreads = omp_get_max_threads();

        // Per-thread RNG
        rngs.resize(nthreads);
        uniforms.resize(nthreads, std::uniform_real_distribution<double>(0, 1));
        for (int t = 0; t < nthreads; t++)
            rngs[t].seed(base_seed + t * 137 + 1);

        weyl.resize(vol);
        ising.resize(vol);
        connL.resize(vol);
        connR.resize(vol);

        // Precompute neighbours
        fwd.resize(vol);
        bwd.resize(vol);
        parities.resize(vol);
        for (int idx = 0; idx < vol; idx++) {
            int x, y, z, t;
            coords(idx, x, y, z, t);
            parities[idx] = ((x+y+z+t) % 2 == 0) ? 1 : -1;
            fwd[idx] = {
                index((x+1)%Ls, y, z, t),
                index(x, (y+1)%Ls, z, t),
                index(x, y, (z+1)%Ls, t),
                index(x, y, z, (t+1)%Lt)
            };
            bwd[idx] = {
                index((x-1+Ls)%Ls, y, z, t),
                index(x, (y-1+Ls)%Ls, z, t),
                index(x, y, (z-1+Ls)%Ls, t),
                index(x, y, z, (t-1+Lt)%Lt)
            };
        }

        // Checkerboard decomposition
        for (int idx = 0; idx < vol; idx++) {
            if (parities[idx] == 1) even_sites.push_back(idx);
            else odd_sites.push_back(idx);
        }
    }

    int index(int x, int y, int z, int t) const {
        return ((x * Ls + y) * Ls + z) * Lt + t;
    }

    void coords(int idx, int& x, int& y, int& z, int& t) const {
        t = idx % Lt; idx /= Lt;
        z = idx % Ls; idx /= Ls;
        y = idx % Ls; idx /= Ls;
        x = idx;
    }

    // =================== RNG ===================

    double urand() {
        int tid = omp_get_thread_num();
        return uniforms[tid](rngs[tid]);
    }

    SU2 random_su2(double epsilon) {
        int tid = omp_get_thread_num();
        std::normal_distribution<double> gauss(0, 1);
        double n1 = gauss(rngs[tid]), n2 = gauss(rngs[tid]), n3 = gauss(rngs[tid]);
        double nrm = sqrt(n1*n1 + n2*n2 + n3*n3);
        if (nrm < 1e-12) return SU2::identity();
        double angle = epsilon * uniforms[tid](rngs[tid]);
        double s = sin(angle) / nrm;
        SU2 r = {cos(angle), s*n1, s*n2, s*n3};
        r.normalize();
        return r;
    }

    // =================== Initialization ===================

    void cold_start() {
        for (int i = 0; i < vol; i++) {
            weyl[i] = {PI/8, PI/8, PI/8};
            ising[i] = parities[i];
            for (int mu = 0; mu < NDIM; mu++) {
                connL[i][mu] = SU2::identity();
                connR[i][mu] = SU2::identity();
            }
        }
        // Small random perturbation to break exact symmetry
        #pragma omp parallel for schedule(static)
        for (int i = 0; i < vol; i++) {
            for (int mu = 0; mu < NDIM; mu++) {
                connL[i][mu] = random_su2(0.3) * connL[i][mu];
                connR[i][mu] = random_su2(0.3) * connR[i][mu];
            }
            for (int a = 0; a < 3; a++)
                weyl[i][a] = PI/8.0 + 0.05 * (urand() - 0.5);
        }
    }

    void hot_start() {
        #pragma omp parallel for schedule(static)
        for (int i = 0; i < vol; i++) {
            for (int a = 0; a < 3; a++)
                weyl[i][a] = urand() * PI / 4.0;
            ising[i] = (urand() < 0.5) ? 1 : -1;
            for (int mu = 0; mu < NDIM; mu++) {
                connL[i][mu] = random_su2(2*PI);
                connR[i][mu] = random_su2(2*PI);
            }
        }
    }

    void set_ising_ordered() {
        for (int i = 0; i < vol; i++) ising[i] = parities[i];
    }

    void set_ising_disordered() {
        for (int i = 0; i < vol; i++) ising[i] = (urand() < 0.5) ? 1 : -1;
    }

    void set_ising_uniform() {
        for (int i = 0; i < vol; i++) ising[i] = 1;
    }

    // =================== Link & Plaquette ===================

    Mat4 link_matrix(int site, int mu) const {
        return embed_su2xu2(connL[site][mu], connR[site][mu])
             * nonlocal_core(weyl[site].data(), ising[site]);
    }

    double plaquette_retrace(int site, int mu, int nu) const {
        int xmu = fwd[site][mu];
        int xnu = fwd[site][nu];
        Mat4 P = link_matrix(site, mu)
               * link_matrix(xmu, nu)
               * link_matrix(xnu, mu).adjoint()
               * link_matrix(site, nu).adjoint();
        return P.trace().real();
    }

    // Action of all plaquettes touching link (site, mu)
    double link_action(int site, int mu) const {
        double S = 0;
        for (int nu = 0; nu < NDIM; nu++) {
            if (nu == mu) continue;
            S -= beta * plaquette_retrace(site, mu, nu);
            S -= beta * plaquette_retrace(bwd[site][nu], mu, nu);
        }
        return S;
    }

    // Action of all plaquettes involving N(x) at site
    double site_N_action(int site) const {
        double S = 0;
        for (int mu = 0; mu < NDIM; mu++) {
            for (int nu = 0; nu < NDIM; nu++) {
                if (nu == mu) continue;
                S -= beta * plaquette_retrace(site, mu, nu);
                S -= beta * plaquette_retrace(bwd[site][nu], mu, nu);
            }
        }
        return S;
    }

    // =================== Updates ===================

    bool update_connection(int site, int mu, double epsilon) {
        SU2 oldL = connL[site][mu], oldR = connR[site][mu];
        double S_old = link_action(site, mu);

        connL[site][mu] = random_su2(epsilon) * oldL;
        connR[site][mu] = random_su2(epsilon) * oldR;
        double S_new = link_action(site, mu);

        if (S_new - S_old < 0 || urand() < exp(-(S_new - S_old))) return true;
        connL[site][mu] = oldL;
        connR[site][mu] = oldR;
        return false;
    }

    bool update_weyl(int site, double epsilon) {
        auto old_c = weyl[site];
        double S_old = site_N_action(site);

        for (int a = 0; a < 3; a++) {
            weyl[site][a] += epsilon * (urand() - 0.5);
            while (weyl[site][a] < 0 || weyl[site][a] > PI/4.0) {
                if (weyl[site][a] < 0) weyl[site][a] = -weyl[site][a];
                if (weyl[site][a] > PI/4.0) weyl[site][a] = PI/2.0 - weyl[site][a];
            }
        }
        double S_new = site_N_action(site);

        if (S_new - S_old < 0 || urand() < exp(-(S_new - S_old))) return true;
        weyl[site] = old_c;
        return false;
    }

    // Checkerboard sweep: update even sites in parallel, then odd
    struct SweepStats { double acc_conn, acc_weyl; };

    SweepStats sweep_gauge(double eps_c, double eps_w) {
        int acc_c = 0, acc_w = 0, tot_c = 0, tot_w = 0;

        // Even sites
        #pragma omp parallel for schedule(dynamic, 64) reduction(+:acc_c,tot_c,acc_w,tot_w)
        for (int idx = 0; idx < (int)even_sites.size(); idx++) {
            int s = even_sites[idx];
            for (int mu = 0; mu < NDIM; mu++) {
                if (update_connection(s, mu, eps_c)) acc_c++;
                tot_c++;
            }
            if (update_weyl(s, eps_w)) acc_w++;
            tot_w++;
        }

        // Odd sites
        #pragma omp parallel for schedule(dynamic, 64) reduction(+:acc_c,tot_c,acc_w,tot_w)
        for (int idx = 0; idx < (int)odd_sites.size(); idx++) {
            int s = odd_sites[idx];
            for (int mu = 0; mu < NDIM; mu++) {
                if (update_connection(s, mu, eps_c)) acc_c++;
                tot_c++;
            }
            if (update_weyl(s, eps_w)) acc_w++;
            tot_w++;
        }

        return {(double)acc_c/std::max(tot_c,1), (double)acc_w/std::max(tot_w,1)};
    }

    // =================== Measurements ===================

    double measure_plaquette() const {
        double sum = 0;
        #pragma omp parallel for schedule(static) reduction(+:sum)
        for (int i = 0; i < vol; i++)
            for (int mu = 0; mu < NDIM; mu++)
                for (int nu = mu+1; nu < NDIM; nu++)
                    sum += plaquette_retrace(i, mu, nu);
        return sum / (6.0 * vol);
    }

    double measure_staggered_mag() const {
        double sum = 0;
        for (int i = 0; i < vol; i++) sum += parities[i] * ising[i];
        return sum / vol;
    }

    struct PolyakovResult { double Lcol, Llep; };

    PolyakovResult measure_polyakov() const {
        int nsp = Ls*Ls*Ls;
        double scol = 0, slep = 0;

        #pragma omp parallel for schedule(static) reduction(+:scol,slep)
        for (int sp = 0; sp < nsp; sp++) {
            int x = sp / (Ls*Ls), y = (sp / Ls) % Ls, z = sp % Ls;
            Mat4 P = Mat4::identity();
            for (int t = 0; t < Lt; t++)
                P = P * link_matrix(index(x,y,z,t), 3);

            Mat4 Pm = G_Mdag * P * G_M;
            cd trc = Pm.m[0][0] + Pm.m[1][1] + Pm.m[2][2];
            scol += std::abs(trc);
            double lq = 0;
            for (int i = 0; i < 3; i++) {
                lq += std::norm(Pm.m[i][3]);
                lq += std::norm(Pm.m[3][i]);
            }
            slep += sqrt(lq);
        }
        return {scol/nsp, slep/nsp};
    }

    double measure_eigenvalue_spread() const {
        double total = 0;
        #pragma omp parallel for schedule(static) reduction(+:total)
        for (int i = 0; i < vol; i++) {
            int j = fwd[i][3];
            Mat4 prod = nonlocal_core(weyl[i].data(), ising[i])
                      * nonlocal_core(weyl[j].data(), ising[j]);
            Mat4 Pm = G_Mdag * prod * G_M;
            double ph[4];
            for (int k = 0; k < 4; k++) ph[k] = std::arg(Pm.m[k][k]);
            double mean3 = (ph[0]+ph[1]+ph[2])/3.0;
            double var3 = 0;
            for (int k = 0; k < 3; k++) var3 += (ph[k]-mean3)*(ph[k]-mean3);
            total += sqrt(var3/3.0);
        }
        return total / vol;
    }
};

// ===================== Jackknife Error =====================

struct JackStats {
    double mean, err;
};

JackStats jackknife(const std::vector<double>& data) {
    int n = data.size();
    if (n < 2) return {data.empty() ? 0 : data[0], 0};
    double total = std::accumulate(data.begin(), data.end(), 0.0);
    double mean = total / n;
    double var = 0;
    for (int i = 0; i < n; i++) {
        double jk = (total - data[i]) / (n - 1);
        var += (jk - mean) * (jk - mean);
    }
    return {mean, sqrt(var * (n-1) / n)};
}

// ===================== Phase Run =====================

struct PhaseData {
    std::string name;
    std::vector<double> plaqs, Lcols, Lleps, spreads;
    JackStats plaq_s, Lcol_s, Llep_s, spread_s;
};

PhaseData run_phase(Lattice& lat, const char* name,
                    int n_therm, int n_meas, int meas_interval)
{
    double eps_c = 0.3, eps_w = 0.2;

    auto t0 = std::chrono::steady_clock::now();

    // Thermalize
    for (int i = 0; i < n_therm; i++) {
        auto st = lat.sweep_gauge(eps_c, eps_w);
        if ((i+1) % 10 == 0) {
            if (st.acc_conn > 0.5) eps_c *= 1.05;
            else if (st.acc_conn < 0.3) eps_c *= 0.95;
            if (st.acc_weyl > 0.5) eps_w *= 1.05;
            else if (st.acc_weyl < 0.3) eps_w *= 0.95;
            eps_c = std::max(0.01, std::min(eps_c, 2.0));
            eps_w = std::max(0.01, std::min(eps_w, 1.0));
        }
    }

    auto t1 = std::chrono::steady_clock::now();
    double therm_sec = std::chrono::duration<double>(t1-t0).count();

    // Measure
    PhaseData pd;
    pd.name = name;

    for (int i = 0; i < n_meas * meas_interval; i++) {
        lat.sweep_gauge(eps_c, eps_w);
        if ((i+1) % meas_interval == 0) {
            pd.plaqs.push_back(lat.measure_plaquette());
            auto poly = lat.measure_polyakov();
            pd.Lcols.push_back(poly.Lcol);
            pd.Lleps.push_back(poly.Llep);
            pd.spreads.push_back(lat.measure_eigenvalue_spread());
        }
    }

    auto t2 = std::chrono::steady_clock::now();
    double meas_sec = std::chrono::duration<double>(t2-t1).count();

    pd.plaq_s = jackknife(pd.plaqs);
    pd.Lcol_s = jackknife(pd.Lcols);
    pd.Llep_s = jackknife(pd.Lleps);
    pd.spread_s = jackknife(pd.spreads);

    printf("  %-22s  plaq=%7.4f(%4.0e)  Lc=%6.3f(%4.0e)  Ll=%6.3f(%4.0e)  sp=%6.4f(%4.0e)  [%.1fs therm + %.1fs meas]\n",
           name,
           pd.plaq_s.mean, pd.plaq_s.err,
           pd.Lcol_s.mean, pd.Lcol_s.err,
           pd.Llep_s.mean, pd.Llep_s.err,
           pd.spread_s.mean, pd.spread_s.err,
           therm_sec, meas_sec);
    fflush(stdout);

    return pd;
}

// ===================== Main =====================

void print_usage() {
    printf("Usage: su4mc_prod [options]\n");
    printf("  --beta VAL       Wilson coupling (default: scan)\n");
    printf("  --Ls VAL         Spatial size (default: 8)\n");
    printf("  --Lt VAL         Temporal size (default: 16)\n");
    printf("  --n_therm VAL    Thermalization sweeps (default: 300)\n");
    printf("  --n_meas VAL     Measurements (default: 100)\n");
    printf("  --interval VAL   Sweeps between measurements (default: 5)\n");
    printf("  --scan           Beta scan mode\n");
    printf("  --sizes           Multi-size finite-size scaling\n");
    printf("  --outdir DIR     Output directory (default: .)\n");
}

int main(int argc, char* argv[]) {
    // Defaults
    double beta_single = -1; // negative = scan mode
    int Ls = 8, Lt = 16;
    int n_therm = 300, n_meas = 100, meas_interval = 5;
    bool do_scan = false;
    bool do_sizes = false;
    std::string outdir = ".";

    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--beta" && i+1 < argc) beta_single = atof(argv[++i]);
        else if (arg == "--Ls" && i+1 < argc) Ls = atoi(argv[++i]);
        else if (arg == "--Lt" && i+1 < argc) Lt = atoi(argv[++i]);
        else if (arg == "--n_therm" && i+1 < argc) n_therm = atoi(argv[++i]);
        else if (arg == "--n_meas" && i+1 < argc) n_meas = atoi(argv[++i]);
        else if (arg == "--interval" && i+1 < argc) meas_interval = atoi(argv[++i]);
        else if (arg == "--scan") do_scan = true;
        else if (arg == "--sizes") do_sizes = true;
        else if (arg == "--outdir" && i+1 < argc) outdir = argv[++i];
        else if (arg == "--help") { print_usage(); return 0; }
    }

    int nthreads = omp_get_max_threads();
    printf("# SU(4) Deficit Lattice Monte Carlo — Production\n");
    printf("# OpenMP threads: %d\n", nthreads);
    printf("# Compile: g++ -O3 -std=c++17 -fopenmp -march=native\n");

    // Build list of (beta, Ls, Lt) runs
    struct RunSpec { double beta; int Ls, Lt; };
    std::vector<RunSpec> runs;

    if (do_sizes) {
        // Finite-size scaling: multiple sizes at several betas
        std::vector<double> betas = {1.0, 2.0, 3.0, 4.0, 6.0};
        std::vector<std::pair<int,int>> sizes = {{6,12},{8,16},{10,20},{12,24}};
        for (auto b : betas)
            for (auto [ls, lt] : sizes)
                runs.push_back({b, ls, lt});
    } else if (do_scan || beta_single < 0) {
        // Beta scan at fixed size
        std::vector<double> betas = {0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 5.0, 6.0, 8.0, 10.0};
        for (auto b : betas)
            runs.push_back({b, Ls, Lt});
    } else {
        // Single run
        runs.push_back({beta_single, Ls, Lt});
    }

    // Open CSV output
    std::string csv_path = outdir + "/su4_results.csv";
    FILE* csv = fopen(csv_path.c_str(), "w");
    fprintf(csv, "beta,Ls,Lt,vol,phase,plaq,plaq_err,Lcol,Lcol_err,Llep,Llep_err,spread,spread_err,col_lep_ratio\n");

    printf("#\n# %-6s %-4s %-4s  %-22s  %-14s %-14s %-14s %-14s\n",
           "beta", "Ls", "Lt", "phase", "plaq", "Lcol", "Llep", "spread");
    printf("# %s\n", std::string(120, '-').c_str());

    for (auto& run : runs) {
        printf("# === beta=%.2f  %d^3 x %d  (vol=%d) ===\n",
               run.beta, run.Ls, run.Lt, run.Ls*run.Ls*run.Ls*run.Lt);

        // --- Ordered phase ---
        Lattice lat_ord(run.Ls, run.Lt, run.beta);
        lat_ord.cold_start();
        PhaseData ord = run_phase(lat_ord, "ORDERED", n_therm, n_meas, meas_interval);

        // --- Disordered phase ---
        Lattice lat_dis(run.Ls, run.Lt, run.beta, 99999);
        lat_dis.hot_start();
        PhaseData dis = run_phase(lat_dis, "DISORDERED", n_therm, n_meas, meas_interval);

        // --- Uniform phase ---
        Lattice lat_uni(run.Ls, run.Lt, run.beta, 77777);
        lat_uni.hot_start();
        lat_uni.set_ising_uniform();
        PhaseData uni = run_phase(lat_uni, "UNIFORM", n_therm, n_meas, meas_interval);

        // Write CSV
        auto write_csv = [&](const PhaseData& pd) {
            double ratio = pd.Lcol_s.mean / std::max(pd.Llep_s.mean, 1e-10);
            fprintf(csv, "%.4f,%d,%d,%d,%s,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.4f\n",
                    run.beta, run.Ls, run.Lt, run.Ls*run.Ls*run.Ls*run.Lt,
                    pd.name.c_str(),
                    pd.plaq_s.mean, pd.plaq_s.err,
                    pd.Lcol_s.mean, pd.Lcol_s.err,
                    pd.Llep_s.mean, pd.Llep_s.err,
                    pd.spread_s.mean, pd.spread_s.err,
                    ratio);
        };
        write_csv(ord);
        write_csv(dis);
        write_csv(uni);
        fflush(csv);

        // Winner
        double best = std::max({ord.plaq_s.mean, dis.plaq_s.mean, uni.plaq_s.mean});
        const char* winner = (best == ord.plaq_s.mean) ? "ORDERED" :
                             (best == dis.plaq_s.mean) ? "DISORDERED" : "UNIFORM";
        double ratio_ord = ord.Lcol_s.mean / std::max(ord.Llep_s.mean, 1e-10);
        printf("  >> WINNER: %s  (plaq_gap=%.3f  col/lep=%.2f  spread=%.4f)\n\n",
               winner,
               ord.plaq_s.mean - dis.plaq_s.mean,
               ratio_ord,
               ord.spread_s.mean);
    }

    fclose(csv);
    printf("# Results written to %s\n", csv_path.c_str());
    printf("# Done.\n");
    return 0;
}
