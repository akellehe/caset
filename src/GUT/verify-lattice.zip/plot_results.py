#!/usr/bin/env python3
"""
plot_results.py — Plot SU(4) deficit Monte Carlo results.

Reads CSV files produced by su4_deficit_mc_production and generates
publication-quality plots.

Usage:
    python3 plot_results.py results_dir/run2_8x16.csv
    python3 plot_results.py results_dir/run5_fss.csv --fss
    python3 plot_results.py results_dir/*.csv --combined
"""

import sys
import os
import csv
import numpy as np

# Try matplotlib; if not available, skip plotting
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import AutoMinorLocator
    HAS_MPL = True
except ImportError:
    HAS_MPL = False
    print("matplotlib not found; will print tables only.")

def read_csv(path):
    """Read a CSV results file into a list of dicts."""
    rows = []
    with open(path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            for key in row:
                try:
                    row[key] = float(row[key])
                except ValueError:
                    pass
            rows.append(row)
    return rows

def split_phases(rows):
    """Split rows by phase name."""
    phases = {}
    for r in rows:
        p = r['phase']
        if p not in phases:
            phases[p] = []
        phases[p].append(r)
    return phases

def get_betas(phase_rows):
    """Extract sorted unique beta values."""
    return sorted(set(r['beta'] for r in phase_rows))

# ===================== Plot Functions =====================

COLORS = {
    'ORDERED': '#2ecc71',
    'DISORDERED': '#e74c3c',
    'UNIFORM': '#3498db',
}
MARKERS = {
    'ORDERED': 'o',
    'DISORDERED': 's',
    'UNIFORM': '^',
}

def setup_axes(ax, xlabel, ylabel, title=None):
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    if title:
        ax.set_title(title, fontsize=13, fontweight='bold')
    ax.tick_params(labelsize=10)
    ax.xaxis.set_minor_locator(AutoMinorLocator())
    ax.yaxis.set_minor_locator(AutoMinorLocator())
    ax.grid(True, alpha=0.2)
    ax.grid(True, which='minor', alpha=0.1)

def plot_plaquette(phases, outpath):
    """Plot average plaquette vs beta for all phases."""
    fig, ax = plt.subplots(figsize=(8, 5))
    setup_axes(ax, r'$\beta$', r'$\langle \mathrm{Re\,tr}\, P \rangle$',
               'Average Plaquette vs Coupling')

    for pname in ['ORDERED', 'DISORDERED', 'UNIFORM']:
        if pname not in phases:
            continue
        rows = sorted(phases[pname], key=lambda r: r['beta'])
        betas = [r['beta'] for r in rows]
        plaqs = [r['plaq'] for r in rows]
        errs = [r['plaq_err'] for r in rows]
        ax.errorbar(betas, plaqs, yerr=errs,
                    label=pname.lower(), color=COLORS[pname],
                    marker=MARKERS[pname], markersize=6, capsize=3,
                    linewidth=1.5)

    ax.legend(fontsize=11, framealpha=0.9)
    fig.tight_layout()
    fig.savefig(outpath, dpi=200)
    print(f"  Saved: {outpath}")
    plt.close(fig)

def plot_polyakov(phases, outpath):
    """Plot colour and leptoquark Polyakov loops vs beta."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    # Left: ordered phase, colour vs lepto
    if 'ORDERED' in phases:
        rows = sorted(phases['ORDERED'], key=lambda r: r['beta'])
        betas = [r['beta'] for r in rows]
        ax1.errorbar(betas, [r['Lcol'] for r in rows], yerr=[r['Lcol_err'] for r in rows],
                     label=r'$|L_{\mathrm{colour}}|$', color='#2ecc71', marker='o',
                     markersize=6, capsize=3, linewidth=1.5)
        ax1.errorbar(betas, [r['Llep'] for r in rows], yerr=[r['Llep_err'] for r in rows],
                     label=r'$|L_{\mathrm{lepto}}|$', color='#e74c3c', marker='s',
                     markersize=6, capsize=3, linewidth=1.5, linestyle='--')
        ax1.axhline(1.0, color='gray', linestyle=':', alpha=0.5)

    setup_axes(ax1, r'$\beta$', r'$\langle |L| \rangle$', 'Ordered Phase: Polyakov Loop Splitting')
    ax1.legend(fontsize=11)

    # Right: colour/lepto ratio
    if 'ORDERED' in phases:
        rows_o = sorted(phases['ORDERED'], key=lambda r: r['beta'])
        betas = [r['beta'] for r in rows_o]
        ratios = [r['col_lep_ratio'] for r in rows_o]
        ax2.plot(betas, ratios, 'o-', color='#8e44ad', markersize=6, linewidth=2,
                 label='ordered')

    if 'DISORDERED' in phases:
        rows_d = sorted(phases['DISORDERED'], key=lambda r: r['beta'])
        betas_d = [r['beta'] for r in rows_d]
        ratios_d = [r['col_lep_ratio'] for r in rows_d]
        ax2.plot(betas_d, ratios_d, 's--', color='#e74c3c', markersize=5, linewidth=1.5,
                 label='disordered', alpha=0.7)

    ax2.axhline(1.0, color='gray', linestyle=':', alpha=0.5, label='no splitting')
    setup_axes(ax2, r'$\beta$', r'$|L_{\mathrm{col}}| / |L_{\mathrm{lep}}|$',
               'Colour/Leptoquark Ratio')
    ax2.legend(fontsize=11)

    fig.tight_layout()
    fig.savefig(outpath, dpi=200)
    print(f"  Saved: {outpath}")
    plt.close(fig)

def plot_spread(phases, outpath):
    """Plot eigenvalue spread vs beta."""
    fig, ax = plt.subplots(figsize=(8, 5))
    setup_axes(ax, r'$\beta$', 'Eigenvalue spread (rad)',
               'Eigenvalue Degeneracy: Spread of First 3 Phases')

    for pname in ['ORDERED', 'DISORDERED', 'UNIFORM']:
        if pname not in phases:
            continue
        rows = sorted(phases[pname], key=lambda r: r['beta'])
        betas = [r['beta'] for r in rows]
        spreads = [r['spread'] for r in rows]
        errs = [r['spread_err'] for r in rows]
        ax.errorbar(betas, spreads, yerr=errs,
                    label=pname.lower(), color=COLORS[pname],
                    marker=MARKERS[pname], markersize=6, capsize=3,
                    linewidth=1.5)

    ax.axhline(0, color='gray', linestyle=':', alpha=0.5, label='perfect 3+1 degeneracy')
    ax.legend(fontsize=11)
    fig.tight_layout()
    fig.savefig(outpath, dpi=200)
    print(f"  Saved: {outpath}")
    plt.close(fig)

def plot_action_gap(phases, outpath):
    """Plot beta * Delta_plaquette vs beta."""
    if 'ORDERED' not in phases or 'DISORDERED' not in phases:
        return

    fig, ax = plt.subplots(figsize=(8, 5))
    setup_axes(ax, r'$\beta$', r'$\beta \cdot \Delta \langle P \rangle$',
               'Action Gap (Ordered - Disordered)')

    rows_o = {r['beta']: r for r in phases['ORDERED']}
    rows_d = {r['beta']: r for r in phases['DISORDERED']}
    common = sorted(set(rows_o.keys()) & set(rows_d.keys()))

    betas = []
    gaps = []
    for b in common:
        dp = rows_o[b]['plaq'] - rows_d[b]['plaq']
        betas.append(b)
        gaps.append(b * dp)

    ax.plot(betas, gaps, 'o-', color='#2ecc71', markersize=7, linewidth=2)
    ax.axhline(0, color='gray', linestyle=':', alpha=0.5)

    # Fit linear trend
    if len(betas) > 2:
        coeffs = np.polyfit(betas, gaps, 1)
        bfit = np.linspace(0, max(betas)*1.1, 100)
        ax.plot(bfit, np.polyval(coeffs, bfit), '--', color='#27ae60', alpha=0.5,
                label=f'linear fit: {coeffs[0]:.2f}β + {coeffs[1]:.2f}')
        ax.legend(fontsize=11)

    fig.tight_layout()
    fig.savefig(outpath, dpi=200)
    print(f"  Saved: {outpath}")
    plt.close(fig)

def plot_fss(all_rows, outpath):
    """Finite-size scaling: plaquette gap vs beta for different volumes."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    # Group by (Ls, Lt)
    sizes = {}
    for r in all_rows:
        key = (int(r['Ls']), int(r['Lt']))
        if key not in sizes:
            sizes[key] = []
        sizes[key].append(r)

    colors_fss = ['#2ecc71', '#3498db', '#e67e22', '#9b59b6', '#e74c3c']

    for i, ((ls, lt), rows) in enumerate(sorted(sizes.items())):
        phases = split_phases(rows)
        if 'ORDERED' not in phases or 'DISORDERED' not in phases:
            continue

        rows_o = {r['beta']: r for r in phases['ORDERED']}
        rows_d = {r['beta']: r for r in phases['DISORDERED']}
        common = sorted(set(rows_o.keys()) & set(rows_d.keys()))

        betas = list(common)
        gaps = [rows_o[b]['plaq'] - rows_d[b]['plaq'] for b in common]
        ratios = [rows_o[b]['col_lep_ratio'] for b in common]
        col = colors_fss[i % len(colors_fss)]
        label = f'${ls}^3 \\times {lt}$'

        ax1.plot(betas, gaps, 'o-', color=col, markersize=5, linewidth=1.5, label=label)
        ax2.plot(betas, ratios, 'o-', color=col, markersize=5, linewidth=1.5, label=label)

    setup_axes(ax1, r'$\beta$', r'$\Delta \langle P \rangle$',
               'Plaquette Gap (Ordered - Disordered)')
    ax1.axhline(0, color='gray', linestyle=':', alpha=0.5)
    ax1.legend(fontsize=10)

    setup_axes(ax2, r'$\beta$', r'$|L_{\mathrm{col}}|/|L_{\mathrm{lep}}|$',
               r'Colour/Leptoquark Ratio (Ordered)')
    ax2.axhline(1.0, color='gray', linestyle=':', alpha=0.5)
    ax2.legend(fontsize=10)

    fig.tight_layout()
    fig.savefig(outpath, dpi=200)
    print(f"  Saved: {outpath}")
    plt.close(fig)

# ===================== Summary Table =====================

def print_summary(phases):
    """Print a formatted summary table."""
    print("\n  SUMMARY TABLE")
    print("  " + "-"*90)
    print(f"  {'beta':>6}  {'phase':<14} {'plaq':>10}  {'Lcol':>10}  {'Llep':>10}  {'col/lep':>8}  {'spread':>10}")
    print("  " + "-"*90)

    all_betas = set()
    for pname in phases:
        for r in phases[pname]:
            all_betas.add(r['beta'])

    for b in sorted(all_betas):
        for pname in ['ORDERED', 'DISORDERED', 'UNIFORM']:
            if pname not in phases:
                continue
            matching = [r for r in phases[pname] if r['beta'] == b]
            if not matching:
                continue
            r = matching[0]
            winner = ''
            # Check if this phase has the highest plaquette at this beta
            all_at_beta = []
            for p2 in phases:
                for r2 in phases[p2]:
                    if r2['beta'] == b:
                        all_at_beta.append((r2['plaq'], p2))
            if all_at_beta:
                best_phase = max(all_at_beta, key=lambda x: x[0])[1]
                if pname == best_phase:
                    winner = ' <<'
            print(f"  {b:6.1f}  {pname:<14} {r['plaq']:10.5f}  {r['Lcol']:10.4f}  {r['Llep']:10.4f}  {r['col_lep_ratio']:8.3f}  {r['spread']:10.5f}{winner}")
        print("  " + "-"*90)

# ===================== Main =====================

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 plot_results.py <csv_file> [--fss] [--combined]")
        return

    csv_files = [f for f in sys.argv[1:] if not f.startswith('--')]
    do_fss = '--fss' in sys.argv
    do_combined = '--combined' in sys.argv

    # Read all CSV files
    all_rows = []
    for path in csv_files:
        if os.path.exists(path):
            rows = read_csv(path)
            all_rows.extend(rows)
            print(f"Read {len(rows)} rows from {path}")
        else:
            print(f"WARNING: {path} not found, skipping")

    if not all_rows:
        print("No data loaded!")
        return

    phases = split_phases(all_rows)
    print(f"Phases: {list(phases.keys())}")

    # Print summary table
    print_summary(phases)

    if not HAS_MPL:
        print("\nInstall matplotlib for plots: pip install matplotlib")
        return

    # Determine output directory
    outdir = os.path.dirname(csv_files[0]) or '.'

    # Generate plots
    print("\nGenerating plots...")
    plot_plaquette(phases, os.path.join(outdir, 'plot_plaquette.png'))
    plot_polyakov(phases, os.path.join(outdir, 'plot_polyakov.png'))
    plot_spread(phases, os.path.join(outdir, 'plot_spread.png'))
    plot_action_gap(phases, os.path.join(outdir, 'plot_action_gap.png'))

    if do_fss:
        plot_fss(all_rows, os.path.join(outdir, 'plot_fss.png'))

    print("\nDone!")

if __name__ == '__main__':
    main()
